# CMR audit presentation

Ten static Beamer frames, 16:9 (240 × 135 mm), in American English.

## Build

Open `main.tex` in a LaTeX editor or upload the complete project to Overleaf and select pdfLaTeX. From the project directory:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice. A current MiKTeX or TeX Live distribution with Beamer, Helvetica, TikZ, amsmath, booktabs, tabularx, and adjustbox is sufficient. No shell escape, network resources, external fonts, or bibliography processor are required. `presentation.pdf` is the compiled deck.

## Content and provenance

Source: `88_Submission/Radiuk_Auditing-Deep-Learning_revised.zip`, cross-checked against the supplied manuscript and figure assets. The exact manuscript title, author names, affiliations, and emails are retained.

1. Title and authors.
2. Problem relevance and task-aware comparisons: Tables 8–9.
3. Purpose, three objectives, and cohort/QC evidence: Table 1.
4. Methods architecture: Figure 1 and all eight Algorithm 1 steps, condensed.
5. Semantic transition and tertiles: Equations 1–4.
6. Rules, guarded inference, and alignment: Equations 5–7.
7. Reconstruction experiments: Tables 2–3, Figures 2–3, Equation 8.
8. Comparator and selective rule results: Tables 4–5, Figure 4.
9. Predicate alignment and perturbations: Tables 6–7, Figure 5, Equations 9–10.
10. Conclusions, limitations, future validation, author contacts, and supporting identities.

All five original research figures are embedded as supplied PDFs. All nine tables retain every data cell. Table and figure captions are shortened for slides; original numbers and LaTeX label keys are preserved. All ten numbered equations are reproduced from the source. The dense evidence slides reflect the requirement to include every table, figure, and formula within ten frames; the PDF supports zooming for detailed reading.

The experiments evaluate deterministic image–mask descriptors, not a trained deep encoder, and training tertiles, not full WEDD. The original architecture's WEDD label is qualified on slide 4. Original predicate plot terminology is qualified on slide 9: infarction concerns remodeling, valvular/congenital items are review proxies, and similarity is not physician agreement. Mixed-unit error and perturbation summaries retain the manuscript's interpretation limits. Published ACDC comparisons use different splits and objectives.

## Template and logos

Adapted from `87_Pres_v0.1.zip` using its KhNU theme, Helvetica typography, blue palette, and geometric title treatment. Slide layout, header, and footer are customized in `main.tex`. The original five theme files remain unchanged and are also retained in `theme-original/` for provenance. Their notices credit original author Michael Wiedau and specify CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/ .

The ADT-ISMDDC logo is at the upper right on slides 2–10 and omitted from slide 1. CEUR-WS, CS, ICST, and KhNU identities supplied in `88_Logos` appear on slide 10. The CEUR SVG is included as a source-format alternative to its PNG. Logos inherited from the older ECG example are not asserted as supporters of this CMR work.

All slides are static. TikZ's `overlay` option is used only for fixed title-page placement; there are no Beamer overlay specifications, incremental reveals, pauses, or duplicate animation pages. Every authored text block has an explicit LaTeX size command, directly or through its layout macro.

## Workflow

Benjamin-Plus guidance was injected for this task, as recommended by https://github.com/JetBrains/benjamin-plus-skill . RTK 0.42.3 was used explicitly for build orchestration. No global agent configuration was changed. All task-created files reside under the requested `07_adt` directory.
