# CMR audit presentation — refined first version

Ten static Beamer frames in American English, 16:9 (240 × 135 mm). This revision preserves the first version’s white background, navy title treatment, teal headings, rectangular cards, and original header/footer structure. Blue, green, amber, and rose accents distinguish selected evidence and interpretation blocks.

## Build

Open main.tex in a LaTeX editor, or upload the complete project to Overleaf and select pdfLaTeX. From this directory:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice. A current MiKTeX or TeX Live distribution with Beamer, Helvetica, Latin Modern, TikZ, amsmath, booktabs, tabularx, and makecell is sufficient. No shell escape, external fonts, network resources, or bibliography processor is required. `presentation.pdf` is the compiled deck.

## Numbering and slide content

Table counters advance automatically in presentation order; their original semantic LaTeX label keys remain intact.

- Slide 1: manuscript title, authors, affiliations, and event.
- Slide 2: Tables 1–2 (manuscript Tables 8–9), prediction and audit comparisons.
- Slide 3: Table 3 (manuscript Table 1), purpose, objectives, cohorts, and QC.
- Slide 4: Figure 1 and Algorithm 1, architecture and eight audit steps.
- Slide 5: Equations 1–4, reconstruction and tertile states.
- Slide 6: Equations 5–7, rules, abstention, and clinical alignment.
- Slide 7: Tables 4–5 (manuscript Tables 2–3), Figures 2–3, Equation 8.
- Slide 8: Tables 6–7 (manuscript Tables 4–5), Figure 4, comparator and rule outcomes.
- Slide 9: Tables 8–9 (manuscript Tables 6–7), Figure 5, Equations 9–10.
- Slide 10: conclusions, limitations, next validation, contacts, and supporting identities.

Figures retain sequential numbers 1–5; equations retain 1–10. All 25 original semantic figure, table, equation, and algorithm label keys are retained. All numerical table entries are preserved. Comparison tables are transposed and textual labels shortened to improve readability.

## Readability and figures

Nominal type sizes are 25.5 pt for the title, 21.5 pt for slide headings, 14.5 pt for normal text, 12.4 pt for card text, 11.5 pt for tables, and 10.5 pt for captions, notes, chart labels, and footers. Mathematical scripts use normal TeX scaling. Tables and charts are not shrunk with resizebox or similar transforms.

Figure 1 is redrawn with native text cards and arrows. Figures 2–4 are native TikZ charts with larger labels. Figure 5 uses labeled, common-scale bars beside the exact similarity values in Table 8. The five supplied original figure PDFs remain in `figures/` for provenance. The rendered presentation uses these clearer reconstructions.

## Scientific scope and sources

Source manuscript: `88_Submission/Radiuk_Auditing-Deep-Learning_revised.zip`. The exact manuscript title, author names, affiliations, contacts, numerical results, and central limitations are retained.

The evaluated release uses deterministic image–mask descriptors, not a trained deep encoder, and training tertiles, not full WEDD. Similarity is not physician agreement. Valvular and congenital items are review proxies. Mixed-unit error and perturbation summaries retain their interpretation limits. Published ACDC comparisons use different splits and objectives. Pending QC review is not confirmed error or completed clinical validation.

## Theme and logos

Adapted from `87_Pres_v0.1.zip`, using its KhNU theme, Helvetica, and blue palette. The first version’s customized visual design is retained. The original theme files and `theme-original/` preserve Michael Wiedau’s notices and CC BY-SA 4.0 licensing: https://creativecommons.org/licenses/by-sa/4.0/ .

ADT-ISMDDC appears at the upper right of slides 2–10. CEUR-WS, CS, ICST, and KhNU identities supplied in `88_Logos` appear on slide 10; the CEUR SVG is also included. Every authored text block has an explicit size command directly or through its layout macro. TikZ’s overlay option only positions the static title design; there are no Beamer incremental overlays or extra animation pages.

Benjamin-Plus and RTK were used in the workflow. All task-created files are under `07_adt`. The previous first-version archive is backed up at `_presentation_work/first-version-before-improvements.zip` outside this delivery archive.
