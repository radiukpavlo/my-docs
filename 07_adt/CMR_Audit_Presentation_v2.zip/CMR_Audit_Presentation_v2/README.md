# CMR audit presentation — template-based revision

This edition remakes all ten slides using substantially more of the supplied `87_Pres_v0.1.zip` KhNU design. Open `main.tex` to edit the presentation; `presentation.pdf` is the compiled result.

## Design and readability

- Restored the supplied technology photograph, angled title panel, KhNU title logo, pale-blue diagonal background, footer identity, and diagonal corner accent.
- Restored the template's polygon headings and blue / green / red block families. Green text and heading backgrounds use a darker tone of the same palette for improved contrast.
- Tables 8 and 9 are transposed into comparison panels at 12 pt, with no automatic shrinking. Table 9 puts correlation above signed bias in each clinical-index cell.
- Main text is 12–14 pt on the 240 × 135 mm canvas; dense result tables are 11.5 pt; captions and plot labels are 10.5 pt. Titles are 21 pt. Equations are wrapped where needed, not scaled to fit. Math subscripts and author affiliation superscripts retain normal typographic proportions.
- Figures 2, 3, and 5 are redrawn as bars aligned directly with their corresponding table rows. This retains the quantitative evidence and figure labels while avoiding duplicate, tiny labels. Figure 4 is redrawn as a readable horizontal bar chart. Figure 1 is an editable, large-label architecture diagram.
- The original figure PDFs and original table/equation sources remain in `original-figures/` and `original-content/` for comparison and provenance. All numerical table data are preserved. Long labels are condensed or expanded through nearby definitions; no data values are replaced with qualitative summaries.

## Build

Use pdfLaTeX in a current MiKTeX or TeX Live installation, or upload the complete directory to Overleaf and select pdfLaTeX:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice. Standard dependencies are Beamer, Helvetica, Latin Modern, TikZ, amsmath, booktabs, tabularx, colortbl, and makecell. No shell escape, external services, or bibliography processor are required. The main file restores Helvetica after loading scalable Latin Modern math fonts.

## Content map

1. Title, authors, affiliations, and conference.
2. Relevance: Tables 8 and 9, with the distinction between diagnostic comparison and auditability.
3. Purpose and objectives: Table 1 and quality-control interpretation.
4. Methods: Figure 1 and the eight steps of Algorithm 1.
5. Methods: Equations 1–4, fitting protocol, and evaluated representation.
6. Methods: Equations 5–7, rules, inference guards, and clinical-predicate eligibility.
7. Experiments: Tables 2–3, Figures 2–3, Equation 8, and external shift.
8. Experiments: Tables 4–5 and Figure 4, with selective-score denominators and comparator uncertainty.
9. Experiments: Tables 6–7, Figure 5, and Equations 9–10.
10. Conclusions, limitations, future validation, all author contacts, and supplied supporting identities.

Original manuscript labels and numbering are retained for all five figures, nine tables, ten equations, and Algorithm 1. Numerical data and evidence boundaries come from `Radiuk_Auditing-Deep-Learning_revised.zip`. The study evaluates deterministic image–mask descriptors and training tertiles, not a trained deep encoder or full WEDD. Clinical predicates remain proxies; similarity is not physician agreement. Mixed-unit errors remain descriptive, and cross-system comparisons use different splits and objectives.

## Template, assets, and attribution

The five KhNU theme files are preserved unchanged; all edition-specific changes are in `main.tex`. The supplied template credits Michael Wiedau and specifies CC BY-SA 4.0 for its theme: https://creativecommons.org/licenses/by-sa/4.0/ . The photograph and logo files are retained as supplied; no new asset license is asserted.

ADT-ISMDDC appears at the upper right on slides 2–10, not on the title slide. KhNU appears in the template's title/footer treatment; CEUR-WS, CS, ICST, and KhNU supporting identities appear on slide 10. The CEUR SVG is included alongside the PNG version used by pdfLaTeX.

All ten frames are static. TikZ `overlay` is used only for fixed backgrounds and title placement; there are no Beamer overlay specifications or incremental reveals. Every authored text block has an explicit size command or is covered by a size-setting layout macro.

The earlier presentation and ZIP have been preserved. This revision was built within the requested `07_adt` directory, using the existing LaTeX, RTK, and Benjamin-Plus workflow.
